using UnityEngine;

public class Dash : MonoBehaviour
{
    public GameObject daggerPrefab;

    public float pullForce = 25f;
    public float boostMultiplier = 2f;
    public float boostDistance = 3f;

    public int dashDamage = 5;

    private GameObject currentDagger;
    private Rigidbody2D rb;

    public SpriteRenderer arrowSprite;
    public bool isPullMode = false;
    public bool isDashing = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        UpdateArrowColor();
    }

    void Update()
    {
        ThrowDagger();
        PullToDagger();
        if (Input.GetMouseButtonDown(1))
        {
            isPullMode = !isPullMode;
            UpdateArrowColor();
        }
    }

    void UpdateArrowColor()
    {
        if (isPullMode)
            arrowSprite.color = Color.blue; // 인력
        else
            arrowSprite.color = Color.red;  // 척력
    }
    void ThrowDagger()
    {
        if (Input.GetMouseButtonDown(0) && currentDagger == null)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            currentDagger = Instantiate(daggerPrefab, mousePos, Quaternion.identity);
        }
    }

    void PullToDagger()
    {
        if ((Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)) 
            && currentDagger != null && !isDashing)
        {
            Vector2 dir = (currentDagger.transform.position - transform.position).normalized;

            float force = pullForce;

            float dist = Vector2.Distance(transform.position, currentDagger.transform.position);

            if (dist < boostDistance)
                force *= boostMultiplier;

            rb.AddForce(dir * force, ForceMode2D.Impulse);

            isDashing = true;
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        isDashing = false;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (isDashing && other.CompareTag("Boss"))
        {
            Boss bossScript = other.GetComponent<Boss>();

            if (bossScript != null)
            {
                bossScript.TakeDamage(dashDamage);
                Debug.Log("보스에게 " + dashDamage + " 데미지!");
            }
        }
        if(other.CompareTag("Dagger"))
        {
            Destroy(other.gameObject);
        }
    }

    
}