using System.Collections.Generic;
using UnityEngine;

public class DaggerManager : MonoBehaviour
{
    public List<Transform> daggers = new List<Transform>();

    public Transform GetNearestDagger()
    {
        Transform nearest = null;
        float dist = Mathf.Infinity;

        foreach (Transform d in daggers)
        {
            if (d == null)
                continue;

            float d2 = Vector2.Distance(transform.position, d.position);

            if (d2 < dist)
            {
                dist = d2;
                nearest = d;
            }
        }

        return nearest;
    }


}