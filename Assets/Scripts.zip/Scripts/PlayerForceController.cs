using UnityEngine;

public class PlayerForceController : MonoBehaviour
{
    public Rigidbody2D rb;

    public Transform arrow;

    public float repelPower = 15f;
    public float maxCharge = 2f;
    public float chargeSpeed = 1.5f;
    public float arrowDistance = 1.5f;

    public float magnetForce = 25f;
    public float magnetRange = 8f;

    public float metalJumpPower = 20f;

    float charge = 0f;
    bool charging = false;

    public Dash dash;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        dash = GetComponent<Dash>();
    }

    void Update()
    {
        ArrowDirection();
        RepelChargeInput();
    }

    void FixedUpdate()
    {
        if (dash != null && dash.isDashing)
            return;

        MagnetForce();
    }

    void RepelChargeInput()
    {
        if (dash != null && dash.isDashing)
            return;

        if (Input.GetMouseButtonDown(0))
        {
            charging = true;
            charge = 0f;
        }

        if (charging)
        {
            charge += Time.deltaTime * chargeSpeed;
            charge = Mathf.Clamp(charge, 0, maxCharge);
        }

        if (Input.GetMouseButtonUp(0))
        {
            Repel();
            charging = false;
        }
    }

    Vector2 GetMouseDirection()
    {
        Vector3 mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        return (mouse - transform.position).normalized;
    }

    void Repel()
    {
        Vector2 dir = arrow.right;

        float force = repelPower * charge;

        RaycastHit2D hit = Physics2D.Raycast(
            arrow.position,
            dir,
            magnetRange
        );

        if (hit && hit.collider.CompareTag("Metal"))
        {
            rb.AddForce(-dir * metalJumpPower, ForceMode2D.Impulse);
        }
        else
        {
            rb.AddForce(-dir * force, ForceMode2D.Impulse);
        }
    }

    void ArrowDirection()
    {
        Vector3 mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        Vector2 dir = (mouse - transform.position).normalized;

        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

        arrow.rotation = Quaternion.Euler(0, 0, angle);

        arrow.position = (Vector2)transform.position + dir * arrowDistance;
    }

    void MagnetForce()
    {
        Vector2 dir = arrow.right;

        RaycastHit2D hit = Physics2D.Raycast(
            arrow.position,
            dir,
            magnetRange
        );

        if (!hit)
            return;

        if (!hit.collider.CompareTag("Metal"))
            return;

        float dist = hit.distance;

        float strength = magnetForce * (1 - dist / magnetRange);

        if (dash.isPullMode)
            rb.AddForce(dir * strength);
        else
            rb.AddForce(-dir * strength);
    }
}