using UnityEngine;

public class Dagger : MonoBehaviour
{
    void Start()
    {
        PlayerForceController player = FindObjectOfType<PlayerForceController>();

        if (player != null)
        {
            player.GetComponent<DaggerManager>().daggers.Add(transform);
        }
    }
}