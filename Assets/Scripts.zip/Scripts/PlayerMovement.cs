using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public int hp = 10;

    private Rigidbody2D rb;
    private Vector2 move;
    private Dash dash;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        dash = GetComponent<Dash>();
    }

    void Update()
    {
        move.x = Input.GetAxisRaw("Horizontal");
        move.y = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        if (dash != null && dash.isDashing)
            return;

        rb.linearVelocity = move.normalized * moveSpeed;
    }
}